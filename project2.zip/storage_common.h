#define PIPE_NAME_TO_STORAGE "pipe_in"
#define PIPE_NAME_FROM_STORAGE "pipe_out"

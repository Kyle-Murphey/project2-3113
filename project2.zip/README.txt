Project 2

author: Kyle Murphey

Resources:
    https://www.geeksforgeeks.org/named-pipe-fifo-example-c-program/
    Linux programmer's manual
    Project specification page